﻿using Application.Interfaces;
using Domain.DTOs;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace JKTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IngestionController : ControllerBase
    {
        private readonly IIngestionService _ingestionService;

        public IngestionController(IIngestionService ingestionService)
        {
            _ingestionService = ingestionService;
        }

        [HttpPost("trigger/{documentId}")]
        public async Task<IActionResult> Trigger(Guid documentId)
        {
            await _ingestionService.TriggerIngestionAsync(documentId);
            return Ok("Ingestion triggered.");
        }

        [HttpGet("status/{documentId}")]
        public async Task<IActionResult> Status(Guid documentId)
        {
            var status = await _ingestionService.GetStatusAsync(documentId);
            return Ok(status);
        }
    }
}
