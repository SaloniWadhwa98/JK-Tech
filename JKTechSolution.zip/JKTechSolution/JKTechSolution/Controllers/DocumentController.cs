﻿using Application.Interfaces;
using Domain.DTOs;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;


namespace JKTech.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DocumentController : ControllerBase
    {
        private readonly IDocumentService _documentService;

        public DocumentController(IDocumentService documentService)
        {
            _documentService = documentService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> Upload([FromForm] DocumentUploadDto dto)
        {
            await _documentService.UploadDocumentAsync(dto);
            return Ok("Document uploaded successfully.");
        }
        [Authorize]
        [HttpPost("upload")]
        public async Task<IActionResult> Upload([FromForm] DocumentUploadDto dto)

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var documents = await _documentService.GetDocumentsAsync();
            return Ok(documents);
        }
    }
}
