﻿using System;

namespace Domain.Entities
{
    public class Document
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string FilePath { get; set; }
        public Guid UploadedBy { get; set; }
        public DateTime UploadedAt { get; set; }
    }
}
