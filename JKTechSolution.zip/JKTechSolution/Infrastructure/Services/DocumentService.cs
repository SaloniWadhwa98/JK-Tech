﻿using Application.Interfaces;
using Infrastructure.Persistence;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
// (keep other usings)

public class DocumentService : IDocumentService
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _env;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public DocumentService(AppDbContext context, IWebHostEnvironment env, IHttpContextAccessor httpContextAccessor)
    {
        _context = context;
        _env = env;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task UploadDocumentAsync(DocumentUploadDto dto)
    {
        var userId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(userId))
            throw new UnauthorizedAccessException("User not authenticated.");

        // Save file to disk
        var uploadsFolder = Path.Combine(_env.ContentRootPath, "UploadedDocuments");
        if (!Directory.Exists(uploadsFolder))
            Directory.CreateDirectory(uploadsFolder);

        var uniqueFileName = $"{Guid.NewGuid()}_{dto.File.FileName}";
        var filePath = Path.Combine(uploadsFolder, uniqueFileName);

        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await dto.File.CopyToAsync(stream);
        }

        var document = new Document
        {
            Id = Guid.NewGuid(),
            Title = dto.Title,
            FilePath = filePath,
            UploadedAt = DateTime.UtcNow,
            UploadedBy = Guid.Parse(userId)
        };

        _context.Documents.Add(document);
        await _context.SaveChangesAsync();
    }
}
