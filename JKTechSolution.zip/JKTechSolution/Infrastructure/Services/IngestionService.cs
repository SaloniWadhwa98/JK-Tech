﻿using Application.Interfaces;
using Domain.DTOs;
using System;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class IngestionService : IIngestionService
    {
        public Task TriggerIngestionAsync(Guid documentId)
        {
            // TODO: Call Spring Boot backend API here
            return Task.CompletedTask;
        }

        public Task<IngestionStatusDto> GetStatusAsync(Guid documentId)
        {
            // TODO: Retrieve from DB or external status service
            return Task.FromResult(new IngestionStatusDto
            {
                DocumentId = documentId,
                Status = "Processing"
            });
        }
    }
}
