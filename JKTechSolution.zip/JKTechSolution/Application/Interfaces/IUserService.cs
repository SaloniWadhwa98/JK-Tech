﻿using Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IUserService
    {
        Task RegisterAsync(UserDto user);
        Task<string> LoginAsync(string email, string password);
        Task<List<UserDto>> GetUsersAsync();
    }
}
