﻿using Domain.DTOs;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IDocumentService
    {
        Task UploadDocumentAsync(DocumentUploadDto dto);
        Task<List<DocumentDto>> GetDocumentsAsync();
    }
}
