﻿using Domain.DTOs;
using System;
using System.Threading.Tasks;

namespace Application.Interfaces
{
    public interface IIngestionService
    {
        Task TriggerIngestionAsync(Guid documentId);
        Task<IngestionStatusDto> GetStatusAsync(Guid documentId);
    }
}
